/** Automatically generated file. DO NOT MODIFY */
package com.hyipc.uhf_r2000;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}