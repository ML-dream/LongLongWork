package com.hyipc.uhf_r2000;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import junit.runner.Version;

import com.halio.r2000;
import com.hyipc.uhf_r2000.hardware.function.UhfComm;
import com.hyipc.util.Logger;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Debug;
import android.support.v4.media.MediaBrowserCompat.MediaItem.Flags;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class TestActivity extends Activity {
	private byte[] mAddr = new byte[1];
	private Spinner mSpinner;
	private HashMap<Integer, Double> mMapFreq = new HashMap<Integer, Double>();// Ƶ��
	private UhfComm uhfComm = new UhfComm();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);
		// initSpinner();
		initFreqMap();
		

	}

	@Override
	protected void onResume() {
		super.onResume();
		uhfComm.init(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		uhfComm.unInit();
	}


	byte baud = 5;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		switch (keyCode) {
		case KeyEvent.KEYCODE_1:
			GetReaderInformation();
			break;
		case KeyEvent.KEYCODE_2:
//			Logger.D("2");
			SetRegion();
			break;
		case KeyEvent.KEYCODE_3:
			setRfPower();
			break;
		case KeyEvent.KEYCODE_4:
			setInventoryScanTime();
			break;
		case KeyEvent.KEYCODE_5:
			SetBeepNotification();
			break;
		case KeyEvent.KEYCODE_6:
			InventoryG2();
			break;
		case KeyEvent.KEYCODE_7:
			ReadData();
			break;
		case KeyEvent.KEYCODE_8:
			WriteData();
			break;
		case KeyEvent.KEYCODE_9:

			
			break;
		case KeyEvent.KEYCODE_BACK:
			this.finish();
			break;
		case KeyEvent.KEYCODE_F1:
			if (baud == 3) {
				baud = 5;
			}else if (baud == 4) {
				baud = 6;
			}
//			Logger.D("baud:"+baud);
			setBaud(baud);
//			baud ++;
			break;
		

		default:
			break;
		}

		return false;
	}
	
	
	

	// WordPtr2 д����ʵ��ַ
	// Wnum2 д���ָ���
	// Writedata2 д������
	private void WriteData() {
		byte[] ComAdr = new byte[1];
		ComAdr[0] = (byte) 0xFF;
		byte QValue = 0;// how many cards scan for one time
		byte Session = 0;
		byte MaskMem = 1;// te:must be 1
		byte[] MaskAdr = new byte[2];
		MaskAdr[0] = MaskAdr[1] = 0;
		byte MaskLen = 8;
		byte[] MaskData = new byte[1];
		MaskData[0] = (byte) 0;
		byte MaskFlag = 0;
		byte AdrTID = 0;
		byte LenTID = 15;
		byte TIDFlag = 0;// te:must be zero
		byte[] pEPCList = new byte[256];
		byte[] Ant1 = new byte[1];
		int[] Totallen = new int[1];
		int[] CardNum = new int[1];

		if (!com.halio.r2000.InventoryG2(ComAdr, QValue, Session, MaskMem, MaskAdr, MaskLen, MaskData, MaskFlag, AdrTID, LenTID, TIDFlag, pEPCList, Ant1, Totallen, CardNum)) {
			// communicate fail
//			Logger.D("InventoryG2 fail");
			// Log.i("TAG", "INVENTORY FAIL...........");
		} else {
//			Logger.D("InventoryG2 succ");
			// Log.i("TAG", "INVENTORY SUCC..........." + Totallen[0] + "  "
			// + CardNum[0]);
			if (Totallen[0] != 0) {
//				Logger.D("Totallen[0] != 0");
				Log.i("TAG", "into..........");
				// Log.i("TAG","epc:-------"+Totallen[0]);
				int totalLength = Totallen[0];
				byte[] pepList = new byte[totalLength - 2];
				for (int i = 0; i < totalLength - 2; i++) {
					pepList[i] = pEPCList[i + 1];
				}

				String strWriteData = "12121212";
				int dataLength = strWriteData.length();
//				byte[] Data = new byte[dataLength];
//				for (int i = 0; i < dataLength; i++) {
//					Log.i("TAG", "i:" + i);
//					Data[i] = (byte) strWriteData.charAt(i);
//				}

				
				byte[] Data = hexStringToBytes(strWriteData);
				for (int i = 0; i < Data.length; i++) {
//					Logger.D(i+" "+Data[i]);
				}
				// String strStartAddr = etStartAddr.getText().toString();
				byte byteStartAddr = (byte) 2;

				if (dataLength % 2 != 0) {
					dataLength += 1;
				}
				byte[] ComAdr2 = new byte[1];
				ComAdr2[0] = 0;
				byte[] EPC2 = pepList;
				byte Enum2 = (byte) 6; // EPC�ֳ���
				byte Wnum2 = (byte) (dataLength / 2); // д���ָ��� 6
				byte Mem2 = (byte) 3; // Ҫд�Ĵ洢�� 0x00:
										// ��������0x01��EPC�洢����0x02��TID�洢����0x03���û��洢����
										// 1
				byte WordPtr2 = byteStartAddr; // ָ��Ҫд�������ʼ��ַ��
												// ��ʾ�ӵ�0����(��һ��16λ�洢��)��ʼд��0x01��ʾ�ӵ�1���ֿ�ʼд
												// 2
				byte[] Writedata2 = Data;
				byte[] Password2 = { (byte) 0, (byte) 0, (byte) 0, (byte) 0 };// 4�ֽڷ�������
				byte MaskMem2 = (byte) 1; // ������,0x01��EPC�洢����0x02��TID�洢����0x03���û��洢����
											// 1
				byte[] MaskAdr2 = { (byte) 0, (byte) 0 }; // �������ʼλ��ַ
				byte MaskLen2 = (byte) 8; // �����λ����
				byte[] MaskData2 = { (byte) 0 }; // �������ݡ�MaskData�����ֽڳ�����MaskLen/8��

				int[] errorcode2 = new int[1];
				errorcode2[0] = -2;

				StringBuffer sbContent = new StringBuffer();
				for (int i = 1; i < EPC2.length; i++) {
					String strnum = Integer.toHexString(pepList[i] & 0xFF);
					if (strnum.length() == 1) {
						sbContent.append("0");
					}
					sbContent.append(strnum);
					sbContent.append("");
				}
//				Logger.D("epc2:"+sbContent.toString());
				
				if (!com.halio.r2000.WriteDataG2(ComAdr2, EPC2, Wnum2, Enum2, Mem2, WordPtr2, Writedata2, Password2, MaskMem2, MaskAdr2, MaskLen2, MaskData2, errorcode2)) {
//					Logger.D("writeData fail");
				} else {
//					Logger.D("writeData succ");
				}
//				Logger.D("error:"+errorcode2[0]);
			}
//			Logger.D("Totallen[0] == 0");
		}

	}

	// Num2 Ҫ��ȡ���ֵĸ���
	// WordPtr2 ָ��Ҫ��ȡ������ʼ��ַ
	// ��ȡ���ȳ�����Χ����ȡʧ��
	private void ReadData() {
		byte[] ComAdr = new byte[1];
		ComAdr[0] = (byte) 0xFF;
		byte QValue = 14;// how many cards scan for one time
		byte Session = 0;
		byte MaskMem = 1;// te:must be 1
		byte[] MaskAdr = new byte[2];
		MaskAdr[0] = MaskAdr[1] = 0;
		byte MaskLen = 8;
		byte[] MaskData = new byte[1];
		MaskData[0] = (byte) 0;
		byte MaskFlag = 0;
		byte AdrTID = 0;
		byte LenTID = 15;
		byte TIDFlag = 0;// te:must be zero
		byte[] pEPCList = new byte[256];
		byte[] Ant1 = new byte[1];
		int[] Totallen = new int[1];
		int[] CardNum = new int[1];
		byte len = 0;
		int length = 0;
		StringBuffer sbEpc = new StringBuffer();

		if (!com.halio.r2000.InventoryG2(ComAdr, QValue, Session, MaskMem, MaskAdr, MaskLen, MaskData, MaskFlag, AdrTID, LenTID, TIDFlag, pEPCList, Ant1, Totallen, CardNum)) {
			// communicate fail
//			Logger.D("InventoryG2 fail");
		} else {
//			Logger.D("InventoryG2 succ");
//			Logger.D("card num:"+CardNum[0]);
			// communicate succ
			if (Totallen[0] != 0) {
				int totalLength = Totallen[0];
				byte[] pepList = new byte[totalLength - 2];
				for (int i = 0; i < totalLength - 2; i++) {
					pepList[i] = pEPCList[i + 1];
				}

				// String StrDataLength = etDataLength.getText()
				// .toString();
				// String StrDataLength = "2";
				// int dataLength = 12;// Ĭ�ϳ���
				// if (StrDataLength != null && StrDataLength.length() != 0) {
				// dataLength = Integer.parseInt(StrDataLength);
				// }

				// byte byteStartAddr = 0;// Ĭ����ʼ��ַ
				// String strStartAddr = etStartAddress.getText()
				// .toString();
				// String strStartAddr = "0";
				// if (strStartAddr != null && strStartAddr.length() != 0) {
				// byteStartAddr = (byte) Integer.parseInt(strStartAddr);
				// }

				byte[] ComAdr2 = new byte[1]; 
				ComAdr2[0] = (byte) 0;
				byte[] EPC2 = pepList;
				byte Enum2 = (byte) 6; // EPC�ֳ���
				byte Mem2 = (byte) 1; // Ҫ��ȡ�Ĵ洢�� 0x00:
										// ��������0x01��EPC�洢����0x02��TID�洢����0x03���û��洢����
										// 1
				byte WordPtr2 = (byte) 0; // ָ��Ҫ��ȡ������ʼ��ַ��0x00
				// ��ʾ�ӵ�0����(��һ��16λ�洢��)��ʼ����0x01��ʾ�ӵ�1���ֿ�ʼ��
				// 2
				byte Num2 = (byte) 4;// Ҫ��ȡ���ֵĸ�������������Ϊ0x00�������ز���������Ϣ
				// 6
				byte[] Password2 = { (byte) 0, (byte) 0, (byte) 0, (byte) 0 };// 4�ֽڷ�������
				byte MaskMem2 = (byte) 1; // ������,0x01��EPC�洢����0x02��TID�洢����0x03���û��洢����
											// 1
				byte[] MaskAdr2 = { (byte) 0, (byte) 0 }; // �������ʼλ��ַ 
				byte MaskLen2 = (byte) 8; // �����λ����
				byte[] MaskData2 = { (byte) 0 }; // �������ݡ�MaskData�����ֽڳ�����MaskLen/8��

				byte MaskFlag2 = (byte) 0;// MaskFlag=1���룬MaskFlag=0�����롣

				byte[] Data2 = new byte[256];
				int[] errorcode2 = new int[1];

				if (!com.halio.r2000.ReadDataG2(ComAdr2, EPC2, Enum2, Mem2, WordPtr2, Num2, Password2, MaskMem2, MaskAdr2, MaskLen2, MaskData2, Data2, errorcode2)) {
//					Logger.D("ReadData fail");
					// Log.i("TAG", "read user fail..........");
				} else {
//					Logger.D("ReadData succ");
					// Log.i("TAG", "read user success..........");
					int dataLength = Num2 * 2;
					// sbEpc.setLength(0);
					for (int i = 0; i < dataLength; i++) {
						// Logger.D(i+" Data2[i]:"+Data2[i]);
						String strnum = Integer.toHexString(Data2[i] & 0xFF);
//						Logger.D(i + " strnum:" + strnum);
						if (strnum.length() == 1) {
							sbEpc.append("0");
						}
						sbEpc.append(strnum);
						sbEpc.append("");
					}
//					Logger.D("epc1:" + sbEpc.toString());

					// for (int i = 0; i < dataLength; i++) {
					// Logger.D(Data2[i]+"");
					// char b = (char) Data2[i];
					// String strnum = Character.toString(b);
					// sbEpc.append(strnum);
					// }
					// String strEpc = sbEpc.toString();
					// Logger.D("epc:" + strEpc);
					// for (int i = 0; i < strEpc.length(); i++) {
					// char ch = strEpc.charAt(i);
					// }

					// if (hashMapInfo.containsKey(strEpc)) {
					// int a = (int) hashMapInfo.get(strEpc);
					// a++;
					// hashMapInfo.put(strEpc, a);
					// } else {
					// hashMapInfo.put(strEpc, 1);
					// }

					sbEpc.setLength(0);

					// updateStatus(UPDATE_ID_INFO, "");
					// playTone();
					// try {
					// Thread.sleep(80);
					// } catch (InterruptedException e) {
					// e.printStackTrace();
					// }
				}

			}
		}

	}

	private void InventoryG2() {
		byte[] ComAdr = new byte[1];
		ComAdr[0] = (byte) 0xFF;
		byte QValue = 14;// how many cards scan for one time
		byte Session = 0;
		byte MaskMem = 1;
		byte[] MaskAdr = new byte[2];
		MaskAdr[0] = MaskAdr[1] = 0;
		byte MaskLen = 8;
		byte[] MaskData = new byte[1];
		MaskData[0] = (byte) 0;
		byte MaskFlag = 0;
		byte AdrTID = 0;
		byte LenTID = 15;
		byte TIDFlag = 0;// te:must be zero
		byte[] pEPCList = new byte[256];
		byte[] Ant1 = new byte[1];
		int[] Totallen = new int[1];
		int[] CardNum = new int[1];

		if (!com.halio.r2000.InventoryG2(ComAdr, QValue, Session, MaskMem, MaskAdr, MaskLen, MaskData, MaskFlag, AdrTID, LenTID, TIDFlag, pEPCList, Ant1, Totallen, CardNum)) {
//			Logger.D("inventoryG2 fail");
		} else {
			byte len = 0;
			int length = 0;
			StringBuffer sbEpc = new StringBuffer();
//			Logger.D("inventoryG2 succ");
//			Logger.D("cardNum:" + CardNum[0]);
			if (Totallen[0] != 0) {
				int totalLength = Totallen[0];
				byte[] pepList = new byte[256];
				for (int i = 0; i < pEPCList.length; i++) {
					pepList[i] = pEPCList[i];
				}
				while (totalLength != 0) {
					length = pepList[0];
					for (int i = 1; i < length + 1; i++) {
						String strnum = Integer.toHexString(pepList[i] & 0xFF);
						if (strnum.length() == 1) {
							sbEpc.append("0");
						}
						sbEpc.append(strnum);
						sbEpc.append("");
					}

					String strEpc = sbEpc.toString();
//					Logger.D("epc:" + strEpc);
//					Logger.D("cardNum:" + CardNum[0]);
//					Logger.D("totollen:" + Totallen[0]);
					byte[] pEPCList_New = new byte[totalLength - length - 2];
					for (int i = 0; i < pEPCList_New.length; i++) {
						pEPCList_New[i] = pepList[i + length + 2];
					}
					pepList = new byte[totalLength - length - 2];
					for (int i = 0; i < pEPCList_New.length; i++) {
						pepList[i] = pEPCList_New[i];
					}
					totalLength = totalLength - length - 2;
					sbEpc.setLength(0);

				}
			}

		}

	}

	private void SetBeepNotification() {
		boolean flag = r2000.SetBeepNotification(mAddr, (byte) 1);
//		Logger.D("SetBeepNotification succ:" + flag);
	}

	private void setInventoryScanTime() {
		boolean flag = r2000.SetInventoryScanTime(mAddr, (byte) 100);
//		Logger.D("SetInventoryScanTime succ:" + flag);
	}

	private void setRfPower() {
		boolean flag = r2000.SetRfPower(mAddr, (byte) 30);
//		Logger.D("setRfPower succ:" + flag);
	}

	private void SetRegion() {
		boolean flag = r2000.SetRegion(mAddr, (byte) 49, (byte) 128);
//		Logger.D("setRegion succ:" + flag);
	}

	private void initFreqMap() {
		if (mMapFreq == null) {
			mMapFreq = new HashMap<Integer, Double>();
		}
		// Fs = 902.75 + N * 0.5 (MHz) ����N��[0,49]
		double freq;
		for (int N = 0; N <= 49; N++) {
			freq = 902.75 + (double) N * 0.5;
			mMapFreq.put(N, freq);
		}
	}

	private void DisConnectReader() {
		boolean succ = r2000.DisConnectReader();
//		Logger.D("disConnectReader succ:" + succ);
	}

	private void ConnectReader(byte baud) {
//		baudrate	ʵ�ʲ�����
//		0	9600bps
//		1	19200 bps
//		2	38400 bps
//		5	57600 bps
//		6	115200 bps
		DisConnectReader();

		byte[] addr = new byte[1];
		addr[0] = (byte) 0XFF;
		if (!r2000.ConnectReader(addr,baud)) {
//			Logger.D("connect fail");
		} else {
//			Logger.D("connect succ");
		}
	}

	private void setBaud(byte baud) {
		byte[] addr = new byte[1];
		addr[0] = (byte) 0XFF;
		long startTime = System.currentTimeMillis();
//		Logger.D("into setBaud");
		if (!r2000.SetBaudRate(addr, (byte) baud)) {
//			Logger.D("setBaud fail!");
		} else {
//			Logger.D("setBaud succ!");
			//�Ͽ�����
			boolean succ = r2000.DisConnectReader();
			if (succ) {
				//����
				if (!r2000.ConnectReader(addr,baud)) {
//					Logger.D("connect fail");
				} else {
//					Logger.D("connect succ");
				}
			}
		}
		long endTime = System.currentTimeMillis();
//		Logger.D("time:" + (endTime - startTime));
	}

	private void GetReaderInformation() {
		// byte addr[] = new byte[1];
		// addr[0] = (byte) 0xFF;
		mAddr[0] = (byte) 0xFF;
		byte Version[] = new byte[2];
		byte Model[] = new byte[1];
		byte SupProtocol[] = new byte[1];
		byte dmaxfre[] = new byte[1];
		byte dminfre[] = new byte[1];
		byte power[] = new byte[1];
		byte ScanTime[] = new byte[1];
		byte Ant[] = new byte[1];

		byte BeepEn[] = new byte[1];
		byte OutputRep[] = new byte[1];
		byte CheckAnt[] = new byte[1];
		if (!r2000.GetReaderInformation(mAddr, Version, Model, SupProtocol, dmaxfre, dminfre, power, ScanTime, Ant, BeepEn, OutputRep, CheckAnt)) {
			Logger.I("GetReaderInformation fail!");
		} else {
			Logger.I("GetReaderInformation succ!");

			Logger.I("addr:" + mAddr[0]);

			String version = Version[0] + "." + Version[1];
			Logger.I("version:" + version);

			String maxFrequency = dmaxfre[0] + "";
			Logger.I("maxFrequency:" + maxFrequency);

			String minFrequency = dminfre[0] + "";
			Logger.I("minFrequency:" + minFrequency);

			String powerBm = power[0] + "";
			Logger.I("power:" + powerBm);

			String scanTime = ScanTime[0] + "";
			Logger.I("scanTime:" + scanTime);

			Logger.I("���ߣ�" + CheckAnt[0]);
		}
	}
	
	public byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		
		if (hexString.length() % 2 != 0) {
			if (hexString.length() == 1) {
				hexString = "0"+hexString;
			}else {
				int len = hexString.length();
				hexString = hexString.substring(0, len - 1) + "0" + hexString.substring(len - 1, len);
			}
		}
		
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}

	/**
	 * Convert char to byte
	 * 
	 * @param c
	 *            char
	 * @return byte
	 */
	private byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}

}
