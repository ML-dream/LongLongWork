package com.hyipc.uhf_r2000;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import com.hyipc.uhf_r2000.adapter.FragmentAdapter;
import com.hyipc.uhf_r2000.fragment.ReadFragment;
import com.hyipc.uhf_r2000.fragment.SetFragment;
import com.hyipc.uhf_r2000.fragment.WriteFragment;
import com.hyipc.uhf_r2000.hardware.function.UhfComm;


import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends FragmentActivity implements OnPageChangeListener, OnCheckedChangeListener {
	  /*public static ServerSocket serverSocket = null;  
	    public static TextView mTextView, textView1;  
	    private String IP = "";  
	    String buffer = "";  */
	private ViewPager mViewPager;
	private FragmentAdapter mAdapter;
	private List<Fragment> mFragments;
	private RadioGroup mRadioGroup;
	private UhfComm mUhfComm;
	private ActivityManager mActivityManager;
	private static final String BARCODE_PROCESS = "com.hyipc.service.barcode";
	private boolean isHasBarcodeService = false;
	
	private void init()   {
		
		mUhfComm = new UhfComm();
		
		mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);

		mViewPager = (ViewPager) findViewById(R.id.viewPager);
		mFragments = new ArrayList<Fragment>();
		mFragments.add(new ReadFragment());
		mFragments.add(new WriteFragment());
		mFragments.add(new SetFragment());
		mAdapter = new FragmentAdapter(getSupportFragmentManager(), mFragments);
		mViewPager.setAdapter(mAdapter);
		mViewPager.setOffscreenPageLimit(0);

		mRadioGroup.setOnCheckedChangeListener(this);
		mViewPager.addOnPageChangeListener(this);
	
	}

/*	public void run2() throws IOException {
		new WriteFragment().run();
	}*/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		System.out.println("main  qidong .....,.,.");
		setContentView(R.layout.activity_main);
				init();
		mActivityManager = (ActivityManager)this.getSystemService(Context.ACTIVITY_SERVICE);
		
		System.out.println("main  qidong .....,.,.");
	
		
		startService(new Intent("service.MyService"));
		
		
		List<ActivityManager.RunningServiceInfo> services = mActivityManager.getRunningServices(100);
		for (int i = 0; i < services.size(); i++) {
			ActivityManager.RunningServiceInfo serviceInfo = services.get(i);
			String process = serviceInfo.process;
			if (process.contentEquals(BARCODE_PROCESS)) {
				//BarcodeService�������У�������͹رմ��ڵĹ㲥
				isHasBarcodeService = true;
				IntentFilter filter = new IntentFilter();
				filter.addAction(ACTION_CLOSE_SUCC);
				registerReceiver(portReceive, filter);
				this.sendBroadcast(new Intent("portOff"));
				return;
			}
		}
		
		
		 /*new Thread() {  
	            public void run() {  
	                Bundle bundle = new Bundle();  
	                bundle.clear();  
	                OutputStream output;  
	                String str = "ͨ�ųɹ�";  
	                try {  
	                    serverSocket = new ServerSocket(30000);  
	                    while (true) {  
	                        Message msg = new Message();  
	                        msg.what = 0x11;  
	                        try {  
	                            Socket socket = serverSocket.accept();  
	                            output = socket.getOutputStream();  
	                            output.write(str.getBytes("UTF-8"));  
	                            output.flush();  
	                            socket.shutdownOutput();  
	                            //mHandler.sendEmptyMessage(0);  
	                            BufferedReader bff = new BufferedReader(new InputStreamReader(socket.getInputStream()));  
	                            String line = null;  
	                            buffer = "";  
	                            while ((line = bff.readLine())!=null) {  
	                                buffer = line + buffer;  
	                            }  
	                            bundle.putString("msg", buffer.toString());  
	                            msg.setData(bundle);  
	                            mHandler.sendMessage(msg);  
	                            bff.close();  
	                            output.close();  
	                            socket.close();  
	                        } catch (IOException e) {  
	                            e.printStackTrace();  
	                        }  
	                    }  
	                } catch (IOException e1) {  
	                    // TODO Auto-generated catch block  
	                    e1.printStackTrace();  
	                }  
	            };  
	        }.start();  */
		
		
		//BarcodeServiceδ��װ��ֱ�Ӵ򿪴���
		boolean succ = mUhfComm.init(MainActivity.this);
		if (!succ) {
			Toast.makeText(MainActivity.this, "UHF init fail", Toast.LENGTH_LONG).show();
			return;
		}
		
		
	}
	

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.rbRead:
			mViewPager.setCurrentItem(0);
			break;
		case R.id.rbWrite:
			mViewPager.setCurrentItem(1);
			break;
		case R.id.rbSet:
			mViewPager.setCurrentItem(2);
			break;
		default:
			break;
		}
		
	}

	@Override
	public void onPageSelected(int arg0) {
		switch (arg0) {
		case 0:
			mRadioGroup.check(R.id.rbRead);
			break;
		case 1:
			mRadioGroup.check(R.id.rbWrite);
			break;
		case 2:
			mRadioGroup.check(R.id.rbSet);
			break;
		default:
			break;
		}
		
	}
	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub

	}
	
	private final long INVER_TIME = 1000;
	private long lastTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			long currTime = System.currentTimeMillis();
			if (currTime - lastTime < INVER_TIME) {
				this.finish();
			}else {
				Toast.makeText(this, "�ٰ�һ���˳�����", Toast.LENGTH_LONG).show();
				lastTime = currTime;
			}
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		//�����KO����Ӧ�ý��̣�Ŀ�ģ�ɱ��readThread������
		mUhfComm.unInit();
		if (isHasBarcodeService) {
			this.sendBroadcast(new Intent("portOn"));
			unregisterReceiver(portReceive);
		}
		portReceive = null;
		System.exit(0);
	}
	
	private final String ACTION_CLOSE_SUCC = "portCloseSucc";
	BroadcastReceiver portReceive = new BroadcastReceiver() {  
        @Override  
        public void onReceive(final Context context, final Intent intent) {  
            Log.d("BARCODE_SERVICE", "onReceive");  
            String action = intent.getAction(); 
            if (TextUtils.isEmpty(action)) {
				return;
			}
  
            if (ACTION_CLOSE_SUCC.equalsIgnoreCase(action)) {  
            	//�������رմ��ڳɹ�
            	boolean succ = mUhfComm.init(MainActivity.this);
        		if (!succ) {
        			Toast.makeText(MainActivity.this, "UHF init fail", Toast.LENGTH_LONG).show();
        			return;
        		}
            } 
        }  
    };  


}
