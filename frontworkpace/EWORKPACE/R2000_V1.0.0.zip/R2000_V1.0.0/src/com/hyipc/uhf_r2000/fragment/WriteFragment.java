package com.hyipc.uhf_r2000.fragment;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.halio.r2000;
import com.hyipc.uhf_r2000.R;
import com.hyipc.uhf_r2000.hardware.function.UhfWrite;

import com.hyipc.util.Logger;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class WriteFragment extends Fragment{
	private RadioGroup mRgMem;
	private EditText mEtAddr,mEtData;
	private Button mBtnWrite;
	private TextView mTvInfo;
	private UhfWrite mWrite;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_write, null);
		mRgMem = (RadioGroup) view.findViewById(R.id.rgMem);
		mEtAddr = (EditText) view.findViewById(R.id.etAddr);
		mEtData = (EditText) view.findViewById(R.id.etData);
		mBtnWrite = (Button) view.findViewById(R.id.btnWrite);
		mTvInfo = (TextView) view.findViewById(R.id.tvInfo);
		
		mBtnWrite.setOnClickListener(onClickListener);
		
		mWrite = new UhfWrite();
		return view;
	}
	
	
	private OnClickListener onClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btnWrite:
				mTvInfo.setText("");
				int checkId = mRgMem.getCheckedRadioButtonId();
				
				/*new MyThread2().start();*/   //�������¼ӵĳ���
				
				byte bMem = 0;
				switch (checkId) {
				case R.id.rbReser:
					bMem = 0;
					break;
				case R.id.rbEpc:
					bMem = 1;
					break;
				case R.id.rbUser:
					bMem = 3;
					break;
				default:
					break;
				}
				
				
				byte bAddr = 0;
				
				
				String strAddr = mEtAddr.getText().toString().trim();
				if (TextUtils.isEmpty(strAddr)) {
					mTvInfo.setText("please input the start address for writing");
					mTvInfo.setTextColor(Color.RED);
					break;
				}else {
					bAddr = Byte.parseByte(strAddr);
				}
				
				String strData = mEtData.getText().toString().trim();
				if (TextUtils.isEmpty(strData)) {
					mTvInfo.setText("please input the data for writing");
					mTvInfo.setTextColor(Color.RED);
					break;
				}
				
				mWrite.setmMem(bMem);
				mWrite.setmWordPtr(bAddr);
				mWrite.setmContent(strData);
				
				boolean isSucc = mWrite.doWrite();
				if (isSucc) {
					mTvInfo.setText("write succ");
					mTvInfo.setTextColor(0xFF005500);
				}else {
					mTvInfo.setText("write fail");
					mTvInfo.setTextColor(Color.RED);
				}
				
				break;

			default:
				break;
			}
		}
	};
	
//���� �����¼� �ĳ���
	/*class MyThread2 extends Thread {

		

		public void run()  {
			// TODO Auto-generated method stub
			ServerSocket ss;
			try {
				ss = new ServerSocket(8898);
				System.out.println("����");
				Socket s =ss.accept();
				InputStream in = s.getInputStream();
				byte[] buf = new byte[1024];
				int len = in.read(buf);
				String text = new String(buf,0,buf.length);
				System.out.println(text);
				OutputStream out = s.getOutputStream();
			    
			
			 byte bMem = 3;
			byte bAddr = 0;
			mWrite.setmMem(bMem);
			mWrite.setmWordPtr(bAddr);
			mWrite.setmContent(text);
			
			boolean isSucc = mWrite.doWrite();
			if (isSucc) {
				out.write("succ".getBytes());
				mTvInfo.setText("write succ");
				mTvInfo.setTextColor(0xFF005500);
			}else {
				out.write("fail".getBytes());
				mTvInfo.setText("write fail");
				mTvInfo.setTextColor(Color.RED);
			}
			 s.close();
			    ss.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		}

	}
*/
		
	
	
	}
	
	

	
	
	
	
	

