package com.hyipc.uhf_r2000.fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.hyipc.uhf_r2000.R;
import com.hyipc.uhf_r2000.adapter.ContentAdapter;
import com.hyipc.uhf_r2000.hardware.assist.UhfMappingRelation;
import com.hyipc.uhf_r2000.hardware.assist.UhfReadListener;
import com.hyipc.uhf_r2000.hardware.assist.UhfSharedPreferenceUtil;
import com.hyipc.uhf_r2000.hardware.assist.UhfUtil;
import com.hyipc.uhf_r2000.hardware.function.UhfRead;
import com.hyipc.uhf_r2000.hardware.function.UhfSetting;
import com.hyipc.uhf_r2000.model.PojoCard;
import com.hyipc.util.Logger;
import com.hyipc.util.ToneUtil;

import android.content.Context;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class ReadFragment extends Fragment {
	private ListView mLvContent;
	private TextView mTvCardCount;
	private Button mBtnScan, mBtnClear;
	private UhfRead mUhfRead;
	private Context mCtx;
	private Map<String, Integer> mMapContent;
	private ContentAdapter mAdapter;
	private List<PojoCard> mArrCard;
	private int mVoice = UhfSharedPreferenceUtil.VOICE_SYSTEM;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		mCtx = getActivity();
		View view = inflater.inflate(R.layout.fragment_read, null);
		mLvContent = (ListView) view.findViewById(R.id.lvContent);
		mTvCardCount = (TextView) view.findViewById(R.id.tvCardCount);
		mBtnScan = (Button) view.findViewById(R.id.btnScan);
		mBtnClear = (Button) view.findViewById(R.id.btnClear);

		mBtnScan.setOnClickListener(listener);
		mBtnClear.setOnClickListener(listener);

		if (mUhfRead == null) {
			mUhfRead = new UhfRead(new UhfReadListener() {
				@Override
				public void onErrorCaughted(String error) {
				}
				
				@Override
				public void onContentCaughted(Object[] obj) {
					Message.obtain(mHandler, MSG_CONTENT, obj).sendToTarget();
				}
			});
		}
		// ���ö���Ϣ����
		mUhfRead.setmMem((byte) UhfSharedPreferenceUtil.getInstance(mCtx).getMem_read());
		mUhfRead.setmWordPtr((byte)UhfSharedPreferenceUtil.getInstance(mCtx).getStartAddr_read());
		mUhfRead.setmNum((byte)UhfSharedPreferenceUtil.getInstance(mCtx).getNum_read());
		mVoice = UhfSharedPreferenceUtil.getInstance(mCtx).getVoice();
		
		mMapContent = new HashMap<String, Integer>();

		mArrCard = new ArrayList<PojoCard>();
		mAdapter = new ContentAdapter(mCtx, mArrCard);
		mLvContent.setAdapter(mAdapter);

		
		
		return view;
	}

	private String content;
	private final int MSG_CONTENT = 1;
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_CONTENT:
				String[] contents = (String[]) (msg.obj);
				synchronized (mMapContent) {
					for (int i = 0; i < contents.length; i++) {
						content = contents[i];
						if (mMapContent.containsKey(content)) {
							int count = Integer.parseInt(mMapContent.get(content).toString());
							count++;
							mMapContent.put(content, count);
						} else {
							mMapContent.put(content, 1);
						}
					}

					updatemArrCard(mMapContent);
					mAdapter.notifyDataSetChanged();
				}

				mTvCardCount.setText(mArrCard.size() + "");
				playTone();
				break;

			default:
				break;
			}
		};
	};
	
	int i = 0;
	private void playTone(){
		switch (mVoice) {
		case UhfSharedPreferenceUtil.VOICE_SYSTEM:
			//ʹ��ϵͳ����
			ToneUtil.getInstace(mCtx).play(ToneUtil.TYPE_SYSTEM);
			break;
		case UhfSharedPreferenceUtil.VOICE_CUSTOM:
			//ʹ���Զ������������������ļ���
				ToneUtil.getInstace(mCtx).play(ToneUtil.TYPE_CUSTOM);
			break;

		default:
			break;
		}
	}

	private boolean isStart = false;
	private OnClickListener listener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btnScan:
				String text = mBtnScan.getText().toString().trim();
				if (text.equalsIgnoreCase("Scan")) {
					mBtnScan.setText("Stop");
					if (!isStart) {
						mUhfRead.start();
						isStart = true;
					} else {
						mUhfRead.reStart();
					}
				} else {
					mBtnScan.setText("Scan");
					mUhfRead.pause();
				}
				break;
			case R.id.btnClear:
				clear();
				break;

			default:
				break;
			}
		}
	};
	
	private void clear(){
		if (mMapContent == null || mArrCard == null || mAdapter == null || mTvCardCount == null) {
			return;
		}
		
		synchronized (mMapContent) {
			mMapContent.clear();
			mArrCard.clear();
			mAdapter.notifyDataSetChanged();
		}
		mTvCardCount.setText(mArrCard.size() + "");
	}

	/**
	 * @todo ���� mArrCard ����
	 * @param map
	 */
	private void updatemArrCard(Map<String, Integer> map) {
		if (map == null) {
			return;
		}

		mArrCard.clear();
		for (Entry entry : map.entrySet()) {
			String content = entry.getKey().toString();
			int count = Integer.parseInt(entry.getValue().toString());
			mArrCard.add(new PojoCard(content, count));
		}
	}

	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
		ToneUtil.getInstace(mCtx).release();
		if (mUhfRead != null) {
			mUhfRead.destroy();
			mUhfRead = null;
		}
		
		super.onDestroyView();
	}


	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}
	

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser) {
			if (mUhfRead == null) {
				mUhfRead = new UhfRead(new UhfReadListener() {
					@Override
					public void onErrorCaughted(String error) {
					}
					
					@Override
					public void onContentCaughted(Object[] obj) {
						Message.obtain(mHandler, MSG_CONTENT, obj).sendToTarget();
					}
				});
			}

			if (mCtx == null) {
				mCtx = getActivity();
			}
			// ���ö���Ϣ����
			mUhfRead.setmMem((byte) UhfSharedPreferenceUtil.getInstance(mCtx).getMem_read());
			mUhfRead.setmWordPtr((byte)UhfSharedPreferenceUtil.getInstance(mCtx).getStartAddr_read());
			mUhfRead.setmNum((byte)UhfSharedPreferenceUtil.getInstance(mCtx).getNum_read());
			mVoice = UhfSharedPreferenceUtil.getInstance(mCtx).getVoice();
			
			isStart = false;
			clear();
			if (mBtnScan != null) {
				mBtnScan.setText("Scan");
			}
			
		} else {
			if (mUhfRead != null) {
				mUhfRead.destroy();
				mUhfRead = null;
			}
		}
	}
	

}
