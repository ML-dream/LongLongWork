/**
 * 
 */
package service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

import com.hyipc.uhf_r2000.hardware.function.UhfWrite;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;

import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.halio.r2000;
import com.hyipc.uhf_r2000.R;
import com.hyipc.uhf_r2000.hardware.function.UhfWrite;

import com.hyipc.util.Logger;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * @author ��־ǿ
 *
 */
@SuppressLint("ShowToast")
public class MyService extends Service{
	private UhfWrite mWrite;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		
		return null;
	}

/*	public void onCreate() {
		super.onCreate();
		System.out.println("��ʼ������������");
		Log.i("service","������������");
		Toast.makeText(MyService.this,"onCreatfdfsdfde..",Toast.LENGTH_LONG);
		mWrite = new UhfWrite();
		new MyThread().start();
		
	}*/
	@SuppressLint("ShowToast")
	public void onStart(Intent intent , int startId) {
		System.out.println("��ʼ��������");
	/*	Log.i("service","��ʼ��������");
		Toast.makeText(MyService.this,"onStart..",Toast.LENGTH_LONG);*/
		
		new MyThread().start();
	}
	
	public void onDestroy() {
		Log.i("service","xiaohui��������");
		Toast.makeText(MyService.this,"destroy..",Toast.LENGTH_LONG);
		
	}
	class MyThread extends Thread {
	

		public void run() {
			mWrite = new UhfWrite();
			System.out.println("��ʼlainjie1111��������");
			    byte bMem = 3;
				byte bAddr = 0;
			try {
				
				ServerSocket ss = new ServerSocket(8898);
				System.out.println("��ʼlainjie22222��������");
				Socket s = ss.accept();
				System.out.println("���ճɹ���333333");
				
			
				InputStream in =s.getInputStream();
				byte[] buf = new byte[1024];
				int len = in.read(buf);
				String text = new String(buf,0,buf.length);
				
				System.out.println(text);
				OutputStream out = s.getOutputStream();   
			  
			    mWrite.setmMem(bMem);
				mWrite.setmWordPtr(bAddr);
				mWrite.setmContent(text);
				
				boolean isSucc = mWrite.doWrite();
				if (isSucc) {
					out.write("succ".getBytes());
					
				}else {
					out.write("fail".getBytes());
				}
				 s.close(); 
			 } catch (SocketTimeoutException aa) {
			 } catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
